#! /usr/bin/env python

# TITULO            : ARPA pipeline
# AUTOR             : Kary Ocana
# DATA              : 01/07/2009
# DIFICULDADE       : 1
# ==============================================================================
# Objetivo do script: Rodado como o programa principal. Executar Mafft, Readseq,
#                     remove_pipe, Modelgenerator, modulos/script e algoritmos de filogenia 
# Usar o argumento  : Ver usage
# ==============================================================================
# Data da ultima alteracao do script: 01/07/2009
# ==============================================================================
#-------------------------------------------------------------------------------
# declarando os modulos a usar 
#-------------------------------------------------------------------------------
import os, sys, commands, re, shutil as sh, optparse
#arpa -t0.7 -f2,3 align_file
import sys
import getopt

from optparse import OptionParser
def main():
  usage = "% arpa [-h] [-t] data_type [-i] file [-o] dirin [-p] phyml [--mg] model [--bp] bootstrap [--nb] nb_categ [--a] alpha [--in] invar"
  #usage = "usage: %prog [options] arg"
  parser = OptionParser(usage)
  parser.add_option("-t", dest="data_type", help="aa or nucl")
  parser.add_option("-i", dest="filename", help="a fasta file to process", metavar="FILE")
  parser.add_option("-o", dest="directory", help="directory for store the results", )
  parser.add_option("-p", dest="program", help="a phylogenetic program", )
  parser.add_option("--mg", dest="model", help="evolutionary model name")
  parser.add_option("--bp", dest="bootstrap", help="number of substitution rate categories")
  parser.add_option("--nb", dest="nb_categ", help="")
  parser.add_option("--a", dest="alpha", help="gamma distribution parameter")
  parser.add_option("--in", dest="invar", help="proportion of invariable sites")
  parser.add_option("-v", action="store_true", dest="verbose")
  parser.add_option("-q", action="store_false", dest="verbose")
  (options, args) = parser.parse_args()
  
  if options.model is None:
    options.model = 'JTT'  
  if options.bootstrap is None:
    options.bootstrap = '100'
  if options.nb_categ is None:
    options.nb_categ = '4'
  if options.alpha is None:
    options.alpha = '1.0'
  if options.invar is None:
    options.invar = '0.0'
 
  #print options.data_type
  dirin = options.directory
  filename = options.filename
  param_model_evol = options.model
  #if len(args) != 1:
  if len(args) == 1:
      parser.error("incorrect number of arguments")

  #criando diretorio
  os.mkdir(dirin) 						                # Cria o subdiretorio
  print 'Directory', dirin,' created sucessfully'
  sh.copy(filename, dirin)
  #-------------------------------------------------------------------------------
  #PARTE I: OBRIGATORIO
  #-------------------------------------------------------------------------------
  # Executando Mafft
  #-------------------------------------------------------------------------------
  import makeMafft_aa 
  makeMafft_aa.paramModuleExecution(dirin)
  #-------------------------------------------------------------------------------
  # Trabalhando com o arquivo mafft
  #-------------------------------------------------------------------------------
  for m in os.listdir(dirin):
    if m.endswith('.mafft'):                                                    
      path_mafft = os.path.join(dirin, m)
      os.chmod(path_mafft, 0755)  # Assume it's a file
  #-------------------------------------------------------------------------------
  # Corregindo Mafft e removendo pipes
  #-------------------------------------------------------------------------------
  import makeRemovePipe_aa 
  corrected_file = makeRemovePipe_aa.paramModule(path_mafft)
  #-------------------------------------------------------------------------------
  # Executando Readseq
  #-------------------------------------------------------------------------------
  import makeReadseq_aa
  makeReadseq_aa.paramModuleReadseq(path_mafft)
  #-------------------------------------------------------------------------------
  # Executando Modelgenerator
  #-------------------------------------------------------------------------------
  import makeModelgenerator_aa
  param_model_evol = makeModelgenerator_aa.paramModuleModelgenerator(dirin, path_mafft)
  #-------------------------------------------------------------------------------
  #PARTE II: PARTE ELETIVA: POR ALGORITMO
  #-------------------------------------------------------------------------------
  #   4.- Executando Phyml
  #-------------------------------------------------------------------------------
  import makePhyml_aa 
  makePhyml_aa.ModulePhyml(dirin, param_model_evol) 

if __name__ == "__main__":
  main()

################################################################################

#else:
#  print 'problem with number of parameters' 
 
###def usage(prog="arpa"):
###usage = "usage: %prog [options] arg1 arg2"
###
###    print """
###ARPA: phylogenetic tree construction
###Choose between 1 or 2 mode:
###
###1.Main Parameters - obligatory:
###  % arpa [-h] [-t <data_type>] [-i <file>] [-o <dirin>] [-p <program>]
### 
###2. Advanced Parameters - optional:
###  % arpa [-h] [-t] [-i] [-o] [-p <PhyML>] [--mg <model>] [--bp <bootstrap>] [--ns <subst_cat>] [--gd <gamma>] [--pi <invar>] 
###  
### -h                     Print this message
### -t <data_type>         Fasta type, possible values nucl, aa 
### -i <file>              The file.fasta in fasta format
### -o <dirin>             The directory that receives the results
### -p <program>           Phylogenetic mode
### -mg <model>            Evolutionary model
### -bp <bootstrap>        Bootstrap (default 100)
### -ns <substitution>     Number of substitution rate categories
### -gd <gamma>            Gamma distribution parameter: estimated
### -pi <invariable>       Proportion of invariable sites: estimated    
###
###Phylogenetic Programs:
### -p <PhyML> # :         Phylogenies by Maximum Likelihood
### -p <paup nj> # :       Neighbor Joining of PAUP: Phylogenetic Analysis Using Parsimony
### -p <paup mp> # :       Maximum Parsimony of PAUP: Phylogenetic Analysis Using Parsimony
### -p <RAxML> # :         Randomized Axelerated Maximum Likelihood 
### -p <weighbor> # :      Weighted Neighbor Joining
### -p <MrBayes> # :       Bayesian Inference of Phylogeny
###
### """
 
  ###o, a = getopt.getopt(sys.argv[1:], 't:i:o:p:mg:bp:ns:gd:pi:h')
  ###opts = {}
  ###print o
  ###print len(a)
  ###for k,v in o:                                                             
  ###  opts[k] = v
  ###if opts.has_key('-h'):                                                   
  ###  usage(); sys.exit(0)
  ###if len(a) == 1:                                                            
  ###  usage(); sys.exit("Erro in numbers of parameters")
  ####declarando as variaveis
  ###type = opts['-t']
  ###filename = opts['-i']
  ###dirin = opts['-o']
  ###program = opts['-p']
  ###model = ['--mg']
  ###bootstrap = ['--bp']
  ###subst_cat = ['--ns']
  ###gamma = ['--gd']
  ###invar = ['--pi']
 
 
  #% ...[-p <paup nj>] [-mg <model>] [-bp <bootstrap>] [-ns <substitution>] [-gd <gamma>] [-pi <invariable sites>]
  #% ...[-p <paup mp>] [-mg <model>] [-bp <bootstrap>] [-ns <substitution>] [-gd <gamma>] [-pi <invariable sites>]
  #% ...[-p <raxml>] [-mg <model>] [-bp <bootstrap>] [-ns <substitution>] [-gd <gamma>] [-pi <invariable sites>]
  #% ...[-p <weighbor>] [-mg <model>] [-bp <bootstrap>] [-ns <substitution>] [-gd <gamma>] [-pi <invariable sites>]
  #% ...[-p <mrbayes>] [-mg <model>] [-bp <bootstrap>] [-ns <substitution>] [-gd <gamma>] [-pi <invariable sites>]
 