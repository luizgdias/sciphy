#! /usr/bin/env python

# TITULO            : ARPA pipeline
# AUTOR             : Kary Ocana
# DATA              : 01/07/2009
# DIFICULDADE       : 1
# ==============================================================================
# Objetivo do script: Rodado como o programa principal. Executar Mafft, Readseq,
#                     remove_pipe, Modelgenerator, modulos/script e algoritmos de filogenia 
# Usar o argumento  : Ver usage
# ==============================================================================
# Data da ultima alteracao do script: 01/07/2009
# ==============================================================================
#-------------------------------------------------------------------------------
# declarando os modulos a usar 
#-------------------------------------------------------------------------------
import os, sys, commands, re, shutil as sh, optparse
import sys
import getopt
from optparse import OptionParser

def validate_parameters(program):
  programAllDefault = ['phyml', 'paup_nj', 'paup_mp', 'raxml', 'weighbor', 'mrbayes']  
  if (esta_em_programAllDefault(program, programAllDefault)):
    return 1
  else:
    print "The program is unrecognizable"
    sys.exit(2)

def esta_em_programAllDefault(program, programAllDefault):
  for p in programAllDefault:
    if program.lower() == p.lower():
      print 'program found: ' + p
      return 1
  return 0

def alphabet_nucl (filename):
  if filename in 'ATGC':
    print "data_type found: nucl (nucleotide)"
  elif filename in 'bdhkmnrsuvwxy':
    print "ambiguous nucleotide"
    sys.exit(2)
  else:
    print "is not a nucleotide"
    sys.exit(2)

def alphabet_aa (filename):
  if ('A' <= filename <= 'Z' or 'a' <= filename <= 'z') and filename not in 'jou JOU':
    print "data_type found: aa (amino acid)"
  else:
    print "is not amino acid"
    sys.exit(2)

def modelgenerator_nucl(model): #mudar para nucl
  modelAllDefault = ['BLOSUM62','CPREV','Dayhoff','JTT','MTREV24','VT','WAG','DCMut','RtREV','MtMam','MtArt','MtREV','poisson','jones','BLOSUM','equalin','GTR'] #suported for phyml, weighbor, raxml and mrbayes 
  if (esta_em_programAllDefault(model, modelAllDefault)):
    return 1
  else:
    print "The model is unrecognizable"
    sys.exit(2)
    
def modelgenerator_aa(model):
  modelAllDefault = ['BLOSUM62','CPREV','Dayhoff','JTT','MTREV24','VT','WAG','DCMut','RtREV','MtMam','MtArt','MtREV','poisson','jones','BLOSUM','equalin','GTR'] #suported for phyml, weighbor, raxml and mrbayes 
  if (esta_em_modelAllDefault(model, modelAllDefault)):
    return 1
  else:
    print "The model is unrecognizable"
    sys.exit(2)

def esta_em_modelAllDefault(model, modelAllDefault):
  for m in modelAllDefault:
    if model.lower() == m.lower():
      print 'model found: ' + m
      return 1
  return 0    
  
def main():
  usage = "% arpa [-h] [-t] data_type [-i] file [-o] dirin [-p] phyml [--mg] model [--bp] bootstrap [--nb] nb_categ [--a] alpha [--in] invar"
  #usage = "usage: %prog [options] arg"
  parser = OptionParser(usage)
  parser.add_option("-t", dest="data_type", help="aa or nucl")
  parser.add_option("-i", dest="filename", help="a fasta file to process", metavar="FILE")
  parser.add_option("-o", dest="directory", help="directory for store the results", )
  parser.add_option("-p", dest="program", help="a phylogenetic program", )
  parser.add_option("--mg", dest="model", help="evolutionary model name")
  parser.add_option("--bp", dest="bootstrap", type="int", help="bootstrap values")
  parser.add_option("--nb", dest="nb_categ", type="int", help="number of substitution rate categories")
  parser.add_option("--a", dest="alpha", type="float", help="gamma distribution parameter")
  parser.add_option("--in", dest="invar", type="float", help="proportion of invariable sites")
  parser.add_option("-v", action="store_true", dest="verbose")
  parser.add_option("-q", action="store_false", dest="verbose")
  (options, args) = parser.parse_args()
  #if len(args) != 1:
  if len(args) == 1:
      parser.error("incorrect number of arguments")
  #4 parametros obrigatorios
  data_type = options.data_type
  dirin = options.directory
  filename = options.filename
  program = options.program
  model = options.model
  bootstrap = options.bootstrap
  nb_categ = options.nb_categ
  alpha = options.alpha
  invar = options.invar
  #Validando programa (filogenetico)
  validate_parameters(program)
  #Validando data_type (alphabeto) 
  if data_type == 'nucl':
    alphabet_nucl(filename)
    #modelgenerator_nucl(model)
  elif data_type == 'aa':
    alphabet_aa(filename)
    #modelgenerator_aa(model)
  else:
    print "pass aa or nucl as data_type"
  
  #criando diretorio
  os.mkdir(dirin) 						                
  print 'Directory', dirin,' created sucessfully'
  sh.copy(filename, dirin)
  #-------------------------------------------------------------------------------
  #PARTE I: OBRIGATORIO
  #-------------------------------------------------------------------------------
  # Executando Mafft
  #-------------------------------------------------------------------------------
  import makeMafft_aa 
  makeMafft_aa.paramModuleExecution(dirin)
  #-------------------------------------------------------------------------------
  # Trabalhando com o arquivo mafft
  #-------------------------------------------------------------------------------
  for m in os.listdir(dirin):
    if m.endswith('.mafft'):                                                    
      path_mafft = os.path.join(dirin, m)
      os.chmod(path_mafft, 0755)  # Assume it's a file
  #-------------------------------------------------------------------------------
  # Corregindo Mafft e removendo pipes
  #-------------------------------------------------------------------------------
  import makeRemovePipe_aa 
  corrected_file = makeRemovePipe_aa.paramModule(path_mafft)
  #-------------------------------------------------------------------------------
  # Executando Readseq
  #-------------------------------------------------------------------------------
  import makeReadseq_aa
  makeReadseq_aa.paramModuleReadseq(path_mafft)
  #-------------------------------------------------------------------------------
  # Executando Modelgenerator
  #-------------------------------------------------------------------------------
  if model is not None and data_type == 'nucl':
    modelgenerator_nucl(model)
  if model is not None and data_type == 'aa':
    modelgenerator_aa(model)
  else:
    print "executing modelgenerator"
    import makeModelgenerator_aa
    model = makeModelgenerator_aa.paramModuleModelgenerator(dirin, path_mafft)
  #-------------------------------------------------------------------------------
  #PARTE II: PARTE ELETIVA: POR ALGORITMO
  #-------------------------------------------------------------------------------
  #   4.- Executando Phyml
  #-------------------------------------------------------------------------------
  if program == 'phyml':
    if bootstrap is None:
      bootstrap = '100'
    if nb_categ is None:
      nb_categ = '4'
    if alpha is None:
      alpha = '1.0'
    if invar is None:
      invar = '0.0'
  
    import makePhyml_aa 
    makePhyml_aa.ModulePhyml(dirin, bootstrap, model, invar, nb_categ, alpha)
  
  
  ###
  ###else:
  ###  "program is missing"

if __name__ == "__main__":
  main()

