#! /usr/bin/env python

# TITULO            : ARPA pipeline
# AUTOR             : Kary Ocana
# DATA              : 01/07/2009
# DIFICULDADE       : 1
# ==============================================================================
# Objetivo do script: Rodado como o programa principal. Executar Mafft, Readseq,
#                     remove_pipe, Modelgenerator, modulos/script e algoritmos de filogenia 
# Usar o argumento  : Ver usage
# ==============================================================================
# Data da ultima alteracao do script: 01/07/2009
# ==============================================================================
#-------------------------------------------------------------------------------
# declarando os modulos a usar 
#-------------------------------------------------------------------------------
import os, sys, commands, re, shutil as sh, optparse
#arpa -t0.7 -f2,3 align_file
import sys
import getopt

def usage(prog="arpa"):                                            
    print """
ARPA: phylogenetic tree construction
Choose between 1 or 2 mode:

1.Main Parameters - obligatory:
  % arpa [-h] [-t <data_type>] [-i <file>] [-o <dirin>] [-p <program>]
 
2. Advanced Parameters - optional:
  % arpa [-h] [-t] [-i] [-o] [-p <PhyML>] [--mg <model>] [--bp <bootstrap>] [--ns <subst_cat>] [--gd <gamma>] [--pi <invar>] 
  
 -h                     Print this message
 -t <data_type>         Fasta type, possible values nucl, aa 
 -i <file>              The file.fasta in fasta format
 -o <dirin>             The directory that receives the results
 -p <program>           Phylogenetic mode
 -mg <model>            Evolutionary model
 -bp <bootstrap>        Bootstrap (default 100)
 -ns <substitution>     Number of substitution rate categories
 -gd <gamma>            Gamma distribution parameter: estimated
 -pi <invariable>       Proportion of invariable sites: estimated    

Phylogenetic Programs:
 -p <PhyML> # :         Phylogenies by Maximum Likelihood
 -p <paup nj> # :       Neighbor Joining of PAUP: Phylogenetic Analysis Using Parsimony
 -p <paup mp> # :       Maximum Parsimony of PAUP: Phylogenetic Analysis Using Parsimony
 -p <RAxML> # :         Randomized Axelerated Maximum Likelihood 
 -p <weighbor> # :      Weighted Neighbor Joining
 -p <MrBayes> # :       Bayesian Inference of Phylogeny

 """
#Main Parameters - obligatory:
o, a = getopt.getopt(sys.argv[1:], 't:i:o:p:mg:bp:ns:gd:pi:h')
opts = {}
print o
print len(a)
for k,v in o:                                                             
  opts[k] = v
if opts.has_key('-h'):                                                   
  usage(); sys.exit(0)
if len(a) == 1:                                                            
  usage(); sys.exit("Erro in numbers of parameters")
#declarando as variaveis
type = opts['-t']
filename = opts['-i']
dirin = opts['-o']
program = opts['-p']
model = ['--mg']
bootstrap = ['--bp']
subst_cat = ['--ns']
gamma = ['--gd']
invar = ['--pi'] 
#criando diretorio
os.mkdir(dirin) 						                # Cria o subdiretorio
print 'Directory', dirin,' created sucessfully'
sh.copy(filename, dirin)
#-------------------------------------------------------------------------------
#PARTE I: OBRIGATORIO
#-------------------------------------------------------------------------------
# Executando Mafft
#-------------------------------------------------------------------------------
import makeMafft_aa 
makeMafft_aa.paramModuleExecution(dirin)
#-------------------------------------------------------------------------------
# Trabalhando com o arquivo mafft
#-------------------------------------------------------------------------------
for m in os.listdir(dirin):
  if m.endswith('.mafft'):                                                    
    path_mafft = os.path.join(dirin, m)
    os.chmod(path_mafft, 0755)  # Assume it's a file
#-------------------------------------------------------------------------------
# Corregindo Mafft e removendo pipes
#-------------------------------------------------------------------------------
import makeRemovePipe_aa 
corrected_file = makeRemovePipe_aa.paramModule(path_mafft)
#-------------------------------------------------------------------------------
# Executando Readseq
#-------------------------------------------------------------------------------
import makeReadseq_aa
makeReadseq_aa.paramModuleReadseq(path_mafft)
  #-------------------------------------------------------------------------------
  # Executando Modelgenerator
  #-------------------------------------------------------------------------------
  #if
  #        if args is None: args = []
  ###import makeModelgenerator_aa
  ###param_model_evol = makeModelgenerator_aa.paramModuleModelgenerator(dirin, path_mafft)
  #-------------------------------------------------------------------------------
  #PARTE II: PARTE ELETIVA: POR ALGORITMO
  #if program == 'phyml':
  #  print "vai executar phyml e estes  sao os argumentos"
  #-------------------------------------------------------------------------------
  #   4.- Executando Phyml
  #-------------------------------------------------------------------------------
  ###import makePhyml_aa 
  ###makePhyml_aa.ModulePhyml(dirin, param_model_evol) 





#else:
#  print 'problem with number of parameters' 
 
 
 
 
  #% ...[-p <paup nj>] [-mg <model>] [-bp <bootstrap>] [-ns <substitution>] [-gd <gamma>] [-pi <invariable sites>]
  #% ...[-p <paup mp>] [-mg <model>] [-bp <bootstrap>] [-ns <substitution>] [-gd <gamma>] [-pi <invariable sites>]
  #% ...[-p <raxml>] [-mg <model>] [-bp <bootstrap>] [-ns <substitution>] [-gd <gamma>] [-pi <invariable sites>]
  #% ...[-p <weighbor>] [-mg <model>] [-bp <bootstrap>] [-ns <substitution>] [-gd <gamma>] [-pi <invariable sites>]
  #% ...[-p <mrbayes>] [-mg <model>] [-bp <bootstrap>] [-ns <substitution>] [-gd <gamma>] [-pi <invariable sites>]
 