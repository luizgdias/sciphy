#! /usr/bin/env python

# TITULO            : ARPA pipeline
# AUTOR             : Kary Ocana
# DATA              : 01/07/2009
# DIFICULDADE       : 1
# ==============================================================================
# Objetivo do script: Rodado como o programa principal. Executar Mafft, Readseq,
#                     remove_pipe, Modelgenerator, modulos/script e algoritmos de filogenia 
# Usar o argumento  : Ver usage
# ==============================================================================
# Data da ultima alteracao do script: 01/07/2009
# ==============================================================================
#-------------------------------------------------------------------------------
# declarando os modulos a usar 
#-------------------------------------------------------------------------------
import os, sys, commands, re, shutil as sh, optparse
import sys
import getopt
from optparse import OptionParser

def validate_parameters(program):
  programAllDefault = ['phyml', 'paup_nj', 'paup_mp', 'raxml', 'weighbor', 'mrbayes']  
  if (esta_em_programAllDefault(program, programAllDefault)):
    return 1
  else:
    print "The program is unrecognizable"
    sys.exit(2)

def esta_em_programAllDefault(program, programAllDefault):
  for p in programAllDefault:
    if program.lower() == p.lower():
      print 'Program found: ' + p
      return 1
  return 0

def alphabet_nucl (filename):
  if filename in 'ATGC':
    print "Data_type found: nucl (nucleotide)"
  elif filename in 'bdhkmnrsuvwxy':
    print "Ambiguous nucleotide"
    sys.exit(2)
  else:
    print "It is not a nucleotide"
    sys.exit(2)

def alphabet_aa (filename):
  if ('A' <= filename <= 'Z' or 'a' <= filename <= 'z') and filename not in 'jou JOU':
    print "Data_type found: aa (amino acid)"
  else:
    print "It is not amino acid"
    sys.exit(2)

def modelgenerator_nucl(model): #mudar para nucl
  modelAllDefault = ['BLOSUM62','CPREV','Dayhoff','JTT','MTREV24','VT','WAG','DCMut','RtREV','MtMam','MtArt','MtREV','poisson','jones','BLOSUM','equalin','GTR'] #suported for phyml, weighbor, raxml and mrbayes 
  if (esta_em_programAllDefault(model, modelAllDefault)):
    return 1
  else:
    print "The model is unrecognizable"
    sys.exit(2)
    
def modelgenerator_aa(model):
  modelAllDefault = ['BLOSUM62','CPREV','Dayhoff','JTT','MTREV24','VT','WAG','DCMut','RtREV','MtMam','MtArt','MtREV','poisson','jones','BLOSUM','equalin','GTR'] #suported for phyml, weighbor, raxml and mrbayes 
  if (esta_em_modelAllDefault(model, modelAllDefault)):
    return 1
  else:
    print "The model is unrecognizable"
    sys.exit(2)

def esta_em_modelAllDefault(model, modelAllDefault):
  for m in modelAllDefault:
    if model.lower() == m.lower():
      print 'Model found: ' + m
      return 1
  return 0    
  
def make_dir(dirin, filename): 
  try:
    os.mkdir(dirin)
    print 'Directory', dirin,'created sucessfully'
  except OSError:
    print "Directory exists"
    sys.exit(2)
  sh.copy(filename, dirin)

def main():
  #usage = "python %prog [-h] [-t] data_type [-i] file [-o] dirin [-p] phyml [--mg] model [--bp] bootstrap [--nb] nb_categ [--a] alpha [--in] invar"
  usage = "%prog [-t] data_type [-o] dirin [-p] phyml [options] <multifasta>"
  parser = OptionParser(usage)
  parser.add_option("-t", dest="data_type", help="aa or nucl")
  #parser.add_option("-i", dest="filename", help="a fasta file to process", metavar="FILE")
  parser.add_option("-o", dest="directory", help="directory for store the results", )
  parser.add_option("-p", dest="program", help="a phylogenetic program:   phyml/paup_nj/paup_mp/raxml/weighbor/mrbayes", )
  parser.add_option("--mg", dest="model", help="evolutionary model name")
  parser.add_option("--bp", dest="bootstrap", type="int", help="bootstrap values")
  parser.add_option("--nb", dest="nb_categ", type="int", help="number of substitution rate categories (phyml/mrbayes)")
  parser.add_option("--a", dest="alpha", type="float", help="gamma distribution parameter (phyml)")
  parser.add_option("--in", dest="invar", type="float", help="proportion of invariable sites (phyml)")
  
  parser.add_option("--rates", dest="rates", type="string", help="Sets the model for among-site rate variation (mrbayes): Equal/Gamma/Propinv/Invgamma/Adgamma")
  #parser.add_option("--in", dest="invar", type="float", help="proportion of invariable sites")
  #parser.add_option("--a", dest="alpha", type="float", help="gamma distribution parameter")
  #parser.add_option("--in", dest="invar", type="float", help="proportion of invariable sites")
  
  parser.add_option("-v", action="store_true", dest="verbose")
  parser.add_option("-q", action="store_false", dest="verbose")
  (options, args) = parser.parse_args()
  if len(args) != 1: 
      parser.error("Incorrect number of arguments")
      sys.exit(2)

  #4 parametros obrigatorios
  data_type = options.data_type
  dirin = options.directory
  filename = sys.argv[len(sys.argv)-1] #options.filename
  program = options.program
  model = options.model
  bootstrap = options.bootstrap
  nb_categ = options.nb_categ
  alpha = options.alpha
  invar = options.invar
  rates = options.rates
  #Validando programa (filogenetico)
  validate_parameters(program)
  #Validando data_type (alphabeto) and model 
  if data_type == 'nucl':
    if model is not None:
      alphabet_nucl(filename)
      modelgenerator_nucl(model)
    if model is None:
      alphabet_nucl(filename)
  elif data_type == 'aa':
    alphabet_aa(filename)
    if model is not None:
      modelgenerator_aa(model)
      make_dir(dirin, filename)
      mafft_clean_readseq(dirin)
      program_execute(dirin, model, program, bootstrap, nb_categ, alpha, invar)
    if model is None:
      make_dir(dirin, filename)
      mafft_clean_readseq(dirin)
      modelmg = modelgenerator_execute(dirin)
      program_execute(dirin, modelmg, program, bootstrap, nb_categ, alpha, invar)
      sys.exit(2)
  else:
    print "Pass 'aa' or 'nucl' as data_type"
    sys.exit(2)
  #-------------------------------------------------------------------------------
  #PARTE I: OBRIGATORIO
def mafft_clean_readseq(dirin):
  #-------------------------------------------------------------------------------
  # Executando Mafft
  #-------------------------------------------------------------------------------
  import makeMafft_aa 
  makeMafft_aa.paramModuleExecution(dirin)
  #-------------------------------------------------------------------------------
  # Trabalhando com o arquivo mafft
  #-------------------------------------------------------------------------------
  for m in os.listdir(dirin):
    if m.endswith('.mafft'):                                                    
      path_mafft = os.path.join(dirin, m)
      os.chmod(path_mafft, 0755)  # Assume it's a file
  #-------------------------------------------------------------------------------
  # Corregindo Mafft e removendo pipes
  #-------------------------------------------------------------------------------
  import makeRemovePipe_aa 
  corrected_file = makeRemovePipe_aa.paramModule(path_mafft)
  #-------------------------------------------------------------------------------
  # Executando Readseq
  #-------------------------------------------------------------------------------
  import makeReadseq_aa
  makeReadseq_aa.paramModuleReadseq(path_mafft)
  #-------------------------------------------------------------------------------
  # Executando Modelgenerator
  #-------------------------------------------------------------------------------
def modelgenerator_execute(dirin):
  import makeModelgenerator_aa
  model_found = makeModelgenerator_aa.paramModuleModelgenerator(dirin)
  return model_found
#-------------------------------------------------------------------------------
#PARTE II: PARTE ELETIVA: POR ALGORITMO
#-------------------------------------------------------------------------------
  #   4.- Executando Phyml
  #-------------------------------------------------------------------------------
def program_execute(dirin, model, program, bootstrap, nb_categ, alpha, invar):  
  if program == 'phyml':
    if bootstrap is None:
      bootstrap = '100'
    if nb_categ is None:
      nb_categ = '4'
    if alpha is None:
      alpha = '1.0'
    if invar is None:
      invar = '0.0'
    import makePhyml_aa_last 
    makePhyml_aa_last.ModulePhyml(dirin, model, bootstrap, nb_categ, alpha, invar)
  
  if program == 'paup_nj':
    if bootstrap is None:
      bootstrap = '10000'
    import makePaupNJParamModule_aa
    makePaupNJParamModule_aa.ModulePaupNJ(dirin, bootstrap)

  if program == 'paup_mp':
    if bootstrap is None:
      bootstrap = '500'
    import makePaupMPParamModule_aa
    makePaupMPParamModule_aa.ModulePaupMP(dirin, bootstrap)

  if program == 'mrbayes':
    if bootstrap is None:
      bootstrap = '10000'
    if rates is not None:
##      validate_rates(rates)
##      def validate_rates(rates):
##        ratesAllDefault = ['Equal', 'Gamma', 'Propinv', 'Invgamma', 'Adgamma']
##        if (esta_em_ratesAllDefault(rates, ratesAllDefault)):
##          return 1
##        else:
##          print "The rates is unrecognizable"
##          sys.exit(2)
##      def esta_em_ratesAllDefault(rates, ratesAllDefault):
##        for r in ratesAllDefault:
##          if rates.lower() == r.lower():
##            print 'rates found: ' + p
##            return 1
##        return 0
##    if rates is None:
##      rates = 'Equal'
###      
      
    
    
    #import makeMrBayes_aa
    #makePaupMPParamModule_aa.ModulePaupMP(dirin, model, bootstrap)
#Ngammacat 4
  #if program == 'Weighbor':
    #if bootstrap is None:
    #  bootstrap = '500'
    #import makePaupMPParamModule_aa
    #makePaupMPParamModule_aa.ModulePaupMP(dirin, bootstrap)

  #if program == 'RAxML':
    #if bootstrap is None:
    #  bootstrap = '500'
    #import makePaupMPParamModule_aa
    #makePaupMPParamModule_aa.ModulePaupMP(dirin, bootstrap)

  ###
  ###else:
  ###  "program is missing"

if __name__ == "__main__":
  main()

