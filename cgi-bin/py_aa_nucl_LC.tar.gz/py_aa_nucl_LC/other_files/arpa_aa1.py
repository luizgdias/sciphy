#! /usr/bin/env python

# TITULO            : Geral Pipeline, profile phylogeny
# AUTOR             : Kary Soriano
# DATA              : 07/01/2008
# DIFICULDADE       : 2
# ==============================================================================
# Objetivo do script: Rodado como o programa principal. Executar Mafft, Readseq,
#                     remove_pipe, Modelgenerator, modulos/script e algoritmos de filogenia 
# Usar o argumento  : Caminho do documento fasta de entrada + Documento x.fasta de entrada
#                     python profile_phylogeny_aa.py caminho_do_diretorio/file_multifasta.fasta
# (CASA)            : python myscript.py /home/kary/dir/d_06_casa/script/script_aa_pipeline/python/fasta/rh/rh.fasta
# (CASA ultima)     : python myscript.py /home/kary/dir/d_06_casa/script/script_aa_pipeline/python/fasta/rh
# ==============================================================================
# Data da ultima alteracao do script: 31/01/2008
#                                   : 07/01/2008
# ==============================================================================
#-------------------------------------------------------------------------------
# declarando os modulos a usar 
#-------------------------------------------------------------------------------
# 1. O modulo os tem logicamente relacao com seu sistema operacional
# 2. E o modulo commands logicamente tem relacao com os comandos deste sistema (seja qualquer um que rode Python) 
import os, sys, commands, re, shutil as sh, optparse
         
#fastaPass = sys.argv[1:]#fasta
#phylogenyPass = sys.argv[2:]#program

###def main():
###  p = optparse.OptionParser()
###  p.add_option('--program', '-p', default="ML")
###  options, arguments = p.parse_args()
###  print 'Executing %s' % options.program
###  
###if __name__ == '__main__':
###  main()
###
###import sys
### 
###print('Os argumentos da linha de comando sao:')
###for i in sys.argv:
###    print(i)
### 
###print('\n\nO PYTHONPATH e', sys.path, '\n')

from optparse import OptionParser
#use = "Usage: %prog [options] argument1 argument2"

#parser = OptionParser(usage = use)
def main():
    usage = "usage: %prog [options] arg"
    parser = OptionParser(usage)
    parser.add_option("-i", "--filename", dest="filename", help="read multifasta from FILENAME")
    parser.add_option("-o", "--directory", dest="directory", help="write output to directory")
    parser.add_option("-p", "--program", dest="program", help="execute multifasta from PROGRAM")
    parser.add_option("-v", "--verbose", action="store_true", dest="verbose")
    parser.add_option("-q", "--quiet", action="store_false", dest="verbose")
    (options, args) = parser.parse_args()
    
    #declarando argumentos
    #infile = args[0]
    #program = args[1]
    bootstrap = 100
    tree = 'BIONJ'

    #print args[0]
    #print args[1]
    #print len(args)
    
    if len(args) == 0:
      parser.error("incorrect number of arguments")
      sys.exit()
    #elif len(args) == 1:
    #  parser.error("incorrect number of arguments: None program")
    #  sys.exit()

    else:# len(args) >= 1:
      i = 1
      while  i < len(args):
        #print i
        #print 'in while'
        #g = lambda x: x*2
        #h = lambda x, y: x*y
        print args
        for arg[1]:
          
          
 
# 3table = {'Sjoerd': 4127, 'Jack': 4098, 'Dcab': 7678}
#3>>> for name, phone in table.items():
#3...     print '%-10s ==> %10d' % (name, phone)
#3... 
#ack       ==>       4098
##Dcab       ==>       7678
#Sjoerd     ==>       4127
 
 
 
 #result = {
 #         '-p': lambda infile: i+1,
          #'-o': lambda i: i + 1,
          #'-bp': lambda i: i + 1
        
 #       }
  #      print result[infile]
#    def make_incrementor(n):
#     return lambda x, incr=n: x+incr

 #   f = make_incrementor(42)


  #    case arg[i] {
  #        case '-p': program = arg[i+1]
  #                   i++
  #        case '-o': outdir = arg[i+1]
  #                   i++
  #        case '-bp': bootstrap = arg[i+1]
   #   }
#nombrefuncion = lambda variable: variable ** 2
        
        
        #increment = lambda x: x + 1,
        #'-i': lambda infile: i+1,
        #'-p': lambda program: i+1
        
        #outdir = args[4]
        i=i+1
        #print i
        #print 'sumado'
        #print infile
      #print program
    #}
    
###    do_it = lambda f: f()
###    
###switch ($value) {
###    case 'a': $result = $x * 5;
###        break;
###    case 'b':
###        $result = $x + 7;
###        break;
###    case 'c':
###        $result = $x - 2;
###        break;
###}
###result = {
###  'a': lambda x: x * 5,
###  'b': lambda x: x + 7,
###  'c': lambda x: x - 2
###}[value](x)



    #if len(args) > 1:
    #    print args[0]
# 
 #       f = file(args[0], "r") 
 #       f.close() 
      
       
  #      path_fasta = os.path.join(dirin, f)
        ###os.chmod(path_fasta, 0755)  # Assume it's a file
        ###os.mkdir(dirin) 						                # Cria o subdiretorio
        ###print 'Subdiretorio', dirin,'criado com sucesso'
        ###sh.move(arquivo, dirin)
        ####-------------------------------------------------------------------------------
        #### Executando Mafft
        ####-------------------------------------------------------------------------------
        ###import makeMafft_aa 
        ###makeMafft_aa.paramModuleExecution(dirin)
        ####-------------------------------------------------------------------------------
        #### Trabalhando com o arquivo mafft
        ####-------------------------------------------------------------------------------
        ###for m in os.listdir(dirin):
        ###  if m.endswith('.mafft'):                                                    
        ###    path_mafft = os.path.join(dirin, m)
        ###    os.chmod(path_mafft, 0755)  # Assume it's a file
        #-------------------------------------------------------------------------------
        # Corregindo Mafft e removendo pipes
        ####-------------------------------------------------------------------------------
        ###import makeRemovePipe_aa 
        ###corrected_file = makeRemovePipe_aa.paramModule(path_mafft)
        ####-------------------------------------------------------------------------------
        #### Executando Readseq
        ####-------------------------------------------------------------------------------
        ###import makeReadseq_aa
        ###makeReadseq_aa.paramModuleReadseq(path_mafft)
        ####-------------------------------------------------------------------------------
        #### Executando Modelgenerator
        ####-------------------------------------------------------------------------------
        ###import makeModelgenerator_aa
        ###param_model_evol = makeModelgenerator_aa.paramModuleModelgenerator(dirin, path_mafft)
        ####-------------------------------------------------------------------------------
        ####   4.- Executando Phyml
        ####-------------------------------------------------------------------------------
        ###import makePhyml_aa 
        ###makePhyml_aa.ModulePhyml(dirin, param_model_evol) 
    #else:
    #  print 'outro problem' 
#    if options.verbose:
#        print "reading %s..." % options.filename
 
    
if __name__ == "__main__":
    main()


#print "Executing: " + arpa
#print "Phylogeny and Settings: " + str(PhylogenyPass)

#nos argumentos de linha de comando
#o nome do programa ja e um argumento
#portanto...

###if (len(sys.argv) == 1):#se num de argumentos == 1
###    print "Nenhum argumento foi passado: fasta, programa!"
###    sys.exit()#forca o fim do programa
###if (len(sys.argv) == 2):#se num de argumentos == 1
###    print "Nenhum programa foi passado!"
###    sys.exit()#forca o fim do programa
###if (len(sys.argv) == 3):#se num de argumentos == 1
###    print "Nenhum programa foi passado!"
###    sys.exit()#forca o fim do programa
###else: #caso contrario, ha mais de um argumento
###    print "\n\nPrimeiro argumento passado: ",sys.argv[1]
###    #imprimir segundo argumento
###    #(o primeiro e o nome do programa, lembra)

    
###raw_input("Pressione ENTER para continuar...\n")

###walk=0
###print "Lista de argumentos:"
###while walk < len(sys.argv):
###    print sys.argv[walk]
###    walk+=1



#Bootstrapping procedure(default 100):    Number of bootstraps:   
#Substitution model:   

#Advanced Settings...
#Number of substitution rate categories:
#Gamma distribution parameter: estimated     fixed:    
#Proportion of invariable sites: estimated     fixed:    
#Transition / transversion ratio (nucleic acids only): estimated     fixed:     

#-------------------------------------------------------------------------------
# Abrindo o diretorio: Trabalhando com o arquivo fasta
#-------------------------------------------------------------------------------
###dirin = sys.argv[1]
####dirin_name_parts = arquivo.split(".");
####dirin = dirin_name_parts.pop(0);                                               # Diretorio dos dados de saida (resultado)
###for f in os.listdir(dirin):
###  if f.endswith('.fasta'):
###  #if f.endswith('.aln'):                                                       # Ou qq tipo de alinhamento                                                  
###    path_fasta = os.path.join(dirin, f)
###    os.chmod(path_fasta, 0755)  # Assume it's a file
###    #print path_fasta
######os.mkdir(dirin) 						                # Cria o subdiretorio
######print 'Subdiretorio', dirin,'criado com sucesso'
######sh.move(arquivo, dirin)						        # Movendo o .fasta para o subdiretorio criado
####-------------------------------------------------------------------------------
#### Executando Mafft
####-------------------------------------------------------------------------------
###import makeMafft_aa 
###makeMafft_aa.paramModuleExecution(dirin)
####-------------------------------------------------------------------------------
#### Trabalhando com o arquivo mafft
####-------------------------------------------------------------------------------
###for m in os.listdir(dirin):
###  if m.endswith('.mafft'):                                                    
###    path_mafft = os.path.join(dirin, m)
###    os.chmod(path_mafft, 0755)  # Assume it's a file
####-------------------------------------------------------------------------------
#### Corregindo Mafft e removendo pipes
####-------------------------------------------------------------------------------
###import makeRemovePipe_aa 
###corrected_file = makeRemovePipe_aa.paramModule(path_mafft)
####-------------------------------------------------------------------------------
#### Executando Readseq
####-------------------------------------------------------------------------------
###import makeReadseq_aa
###makeReadseq_aa.paramModuleReadseq(path_mafft)
####-------------------------------------------------------------------------------
#### Executando Modelgenerator
####-------------------------------------------------------------------------------
###import makeModelgenerator_aa
###param_model_evol = makeModelgenerator_aa.paramModuleModelgenerator(dirin, path_mafft)
####-------------------------------------------------------------------------------
#### Executando Algoritmos Filogeneticos 
####-------------------------------------------------------------------------------
####-------------------------------------------------------------------------------
####   3.- Executando PaupNJ
####-------------------------------------------------------------------------------
####import makePaupNJ_aa
####makePaupNJ_aa.ModulePaupNJ(dirin, path_mafft)
####-------------------------------------------------------------------------------
####   7.- Executando RAxML
####-------------------------------------------------------------------------------
####import makeRaxml_aa
####makeRaxml_aa.ModuleRaxml(dirin, param_model_evol)
####-------------------------------------------------------------------------------
####   5.- Executando Weighbor VER ERRO DO USO DO L
####-------------------------------------------------------------------------------
####import makeWeighbor_aa
####makeWeighbor_aa.ModuleWeighbor(dirin, param_model_evol)
####-------------------------------------------------------------------------------
####   1.- Executando MrBayes
####-------------------------------------------------------------------------------
####import makeMrBayes_aa
####makeMrBayes_aa.ModuleMrBayes(dirin, param_model_evol)
####-------------------------------------------------------------------------------
####   2.- Executando PaupMP
####-------------------------------------------------------------------------------
####import makePaupMP_aa
####makePaupMP_aa.ModulePaupMP(dirin, path_mafft)
####-------------------------------------------------------------------------------
####   4.- Executando Phyml
####-------------------------------------------------------------------------------
####import makePhyml_aa 
####makePhyml_aa.ModulePhyml(dirin, param_model_evol) 
####-------------------------------------------------------------------------------
####   6.- Executando Filogenia de Perfis
####-------------------------------------------------------------------------------
#####Ainda em proceso falta concatenar
####&makeFilogeniaPerfis($dirin)                 
###
###
###
###
###
###
###
###
###
###
###
###
####-------------------------------------------------------------------------------
####   X.- Executando Paml
####-------------------------------------------------------------------------------
######import makePaml_aa
######makePaml_aa.ParamModulePaml(dirin, param_model_evol)
###
###
###  
###
#        """retorna a paridade de um numero dado"""
        #if i % 2 == 0:
        #  print i, "e par"
        #else:
        #  print i, "e impar"
