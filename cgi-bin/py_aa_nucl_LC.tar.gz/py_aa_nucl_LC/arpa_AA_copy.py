#! /usr/bin/env python

# TITULO            : ARPA pipeline
# AUTOR             : Kary Ocana
# DATA              : 01/07/2009
# DIFICULDADE       : 1
# ==============================================================================
# Objetivo do script: Rodado como o programa principal. Executar Mafft, Readseq,
#                     remove_pipe, Modelgenerator, modulos/script e algoritmos de filogenia 
# Usar o argumento  : Ver usage
# ==============================================================================
# Data da ultima alteracao do script: 01/07/2009
# ==============================================================================
#-------------------------------------------------------------------------------
# declarando os modulos a usar 
#-------------------------------------------------------------------------------
import os, sys, commands, re, shutil as sh, optparse
import sys
import getopt
from optparse import OptionParser

def validate_parameters(program):
  programAllDefault = ['phyml', 'paup_nj', 'paup_mp', 'weighbor', 'mrbayes', 'raxml', 'algorithms_aa_1', 'algorithms_aa_2', 'algorithms_aa_3']  
  if (esta_em_programAllDefault(program, programAllDefault)):
    return 1
  else:
    print "The program is unrecognizable"
    sys.exit(2)

def esta_em_programAllDefault(program, programAllDefault):
  for p in programAllDefault:
    if program.lower() == p.lower():
      print 'Program found: ' + p
      return 1
  return 0

def alphabet_nucl (filename):
  if filename in 'ATGC':
    print "Data_type found: nucl (nucleotide)"
  elif filename in 'bdhkmnrsuvwxy':
    print "Ambiguous nucleotide"
    sys.exit(2)
  else:
    print "It is not a nucleotide"
    sys.exit(2)

def alphabet_aa (filename):
  if ('A' <= filename <= 'Z' or 'a' <= filename <= 'z'):# and filename not in 'jou JOU':
    print "Data_type found: aa (amino acid)"
  else:
    print "It is not amino acid"
    sys.exit(2)

def modelgenerator_nucl(model): #mudar para nucl
  modelAllDefault = ['BLOSUM62','CPREV','Dayhoff','JTT','MTREV24','VT','WAG','DCMut','RtREV','MtMam','MtArt','MtREV','poisson','jones','BLOSUM','equalin','GTR'] #suported for phyml, weighbor, raxml and mrbayes 
  if (esta_em_programAllDefault(model, modelAllDefault)):
    return 1
  else:
    print "The model is unrecognizable"
    sys.exit(2)
    
def modelgenerator_aa(model):
  modelAllDefault = ['BLOSUM62','CPREV','Dayhoff','JTT','MTREV24','VT','WAG','DCMut','RtREV','MtMam','MtArt','MtREV','poisson','jones','BLOSUM','equalin','GTR'] #suported for phyml, weighbor, raxml and mrbayes 
  if (esta_em_modelAllDefault(model, modelAllDefault)):
    return 1
  else:
    print "The model is unrecognizable"
    sys.exit(2)

def esta_em_modelAllDefault(model, modelAllDefault):
  for m in modelAllDefault:
    if model.lower() == m.lower():
      print 'Model found: ' + m
      return 1
  return 0    
  
def make_dir(dirin, filename): 
  try:
    os.mkdir(dirin)
    print 'Directory', dirin,'created sucessfully'
  except OSError:
    print "Directory exists"
    sys.exit(2)
  sh.copy(filename, dirin)

def lset_rates_mrbayes_aa(rates_mrbayes):
  ratesAllDefault = ['Equal','Gamma','Propinv','Invgamma','Adgamma'] #suported for mrbayes 
  if (esta_em_ratesAllDefault(rates, ratesAllDefault)):
    return 1
  else:
    print "The rates for mrbayes is unrecognizable"
    sys.exit(2)

def rates_raxml(rates_raxml):
  ratesAllDefault = ['PROTCAT','PROTMIX','PROTGAMMA','PROTCAT_GAMMA','PROTGAMMAI','PROTMIXI','PROTCAT_GAMMAI'] #suported for raxml
  if (esta_em_ratesAllDefault(rates_raxml, ratesAllDefault)):
    return 1
  else:
    print "The rates for raxml is unrecognizable"
    sys.exit(2)

def freq_raxml(freq_raxml):
  freqAllDefault = ['F'] #suported for raxml
  if (esta_em_freqAllDefault(freq_raxml, freqAllDefault)):
    return 1
  else:
    print "The rates for raxml is unrecognizable"
    sys.exit(2)
    
def main():
  #usage = "python %prog [-h] [-t] data_type [-i] file [-o] dirin [-p] phyml [--mg] model [--bp] bootstrap [--nb] nb_categ [--a] alpha [--in] invar"
  usage = "%prog [-t] data_type [-o] dirin [-p] program [options] <multifasta.fasta>"
  parser = OptionParser(usage)
  parser.add_option("-t", dest="data_type", help="amino acid or nucluotide: aa/nucl")
  #parser.add_option("-i", dest="filename", help="a fasta file to process", metavar="FILE")
  parser.add_option("-o", dest="directory", help="directory for store the results", )
  parser.add_option("-p", dest="program", help="phylogenetic program: phyml/paup_nj/paup_mp/weighbor/mrbayes/raxml/algorithms_aa_1(phyml,paup_nj,paup_mp)/algorithms_aa_2(paup_nj,weighbor,raxMl)/algorithms_aa_3(all)",)
  parser.add_option("--mg", dest="model", help="evolutionary model name")
  parser.add_option("--bp", dest="bootstrap", type="int", help="bootstrap values")
  parser.add_option("--ngen", dest="ngeneration", type="int", help="generation number (mrbayes)")
  parser.add_option("--printfreq", dest="printfreq", type="int", help="how often information about the chain is printed to the screen (mrbayes)")
  parser.add_option("--samplefreq", dest="samplefreq", type="int", help="how often the Markov chain is sampled (mrbayes)")
  parser.add_option("--nchains", dest="nchains", type="int", help="how many chains are run for each analysis for the MCMCMC variant (mrbayes)")                                        
  parser.add_option("--burnin", dest="burnin", type="int", help="the number of samples that will be discarded when convergence diagnostics are calculated (mrbayes)")                                         
  parser.add_option("--nruns", dest="nruns", type="int", help="how many independent analyses are started simultaneously (mrbayes)")                                         
  parser.add_option("--rates_mrbayes", dest="rates_mrbayes", type="float", help="sets the model for among-site rate variation: Equal,Gamma,Propinv,Invgamma,Adgamma (mrbayes)")
  parser.add_option("--nb", dest="nb_categ", type="int", help="number of substitution rate categories (phyml)")
  parser.add_option("--a", dest="alpha", type="float", help="gamma distribution values (phyml)")
  parser.add_option("--in", dest="invar", type="float", help="proportion of invariable sites (phyml)")
  parser.add_option("--rates_raxml_aa", dest="rates_raxml_aa", type="float", help="substitution rates: PROTCAT,PROTMIX,PROTGAMMA,PROTCAT_GAMMA,PROTGAMMAI,PROTMIXI,PROTCAT_GAMMAI (raxml)")
  parser.add_option("--freq_raxml_aa", dest="freq_raxml_aa", type="float", help="use empirical base frequencies: F (raxml)")
  parser.add_option("-v", action="store_true", dest="verbose")
  parser.add_option("-q", action="store_false", dest="verbose")
  (options, args) = parser.parse_args()
  if len(args) != 1: 
      parser.error("Incorrect number of arguments")
      sys.exit(2)

  #4 parametros obrigatorios
  data_type = options.data_type
  dirin = options.directory
  filename = sys.argv[len(sys.argv)-1] #options.filename
  program = options.program
  model = options.model
  bootstrap = options.bootstrap
  ngeneration = options.ngeneration
  printfreq = options.printfreq
  samplefreq = options.samplefreq
  nchains = options.nchains
  burnin = options.burnin
  nruns = options.nruns
  rates_mrbayes = options.rates_mrbayes
  nb_categ = options.nb_categ
  alpha = options.alpha
  invar = options.invar
  rates_raxml_aa = options.rates_raxml_aa
  freq_raxml_aa = options.freq_raxml_aa
  
  #Validando programa (filogenetico)
  validate_parameters(program)
  
  #Validando data_type (alphabeto) and model 
  if data_type == 'nucl':
    if model is not None:
      alphabet_nucl(filename)
      modelgenerator_nucl(model)
      mafft_clean_readseq(dirin)
      #program_execute(dirin, model, program, bootstrap, ngeneration, printfreq, samplefreq, nchains, burnin, nruns, rates_mrbayes, nb_categ, alpha, invar, rates_raxml_aa, freq_raxml_aa)
    if model is None:
      alphabet_nucl(filename)
  
  elif data_type == 'aa':
    alphabet_aa(filename)
    if model is not None:
      modelgenerator_aa(model)
      make_dir(dirin, filename)
      mafft_clean_readseq(dirin)
      program_execute(dirin, model, program, bootstrap, ngeneration, printfreq, samplefreq, nchains, burnin, nruns, rates_mrbayes, nb_categ, alpha, invar, rates_raxml_aa, freq_raxml_aa)
    if model is None:
      make_dir(dirin, filename)
      mafft_clean_readseq(dirin)
      modelmg = modelgenerator_execute(dirin)
      program_execute(dirin, modelmg, program, bootstrap, ngeneration, printfreq, samplefreq, nchains, burnin, nruns, rates_mrbayes, nb_categ, alpha, invarrates_raxml_aa,freq_raxml_aa)
      sys.exit(2)
  else:
    print "Pass 'aa' or 'nucl' as data_type"
    sys.exit(2)
  #-------------------------------------------------------------------------------
  #PARTE I: OBRIGATORIO
def mafft_clean_readseq(dirin):
  #-------------------------------------------------------------------------------
  # Executando Mafft
  #-------------------------------------------------------------------------------
  import makeMafft_aa 
  makeMafft_aa.paramModuleExecution(dirin)
  #-------------------------------------------------------------------------------
  # Trabalhando com o arquivo mafft
  #-------------------------------------------------------------------------------
  for m in os.listdir(dirin):
    if m.endswith('.mafft'):                                                    
      path_mafft = os.path.join(dirin, m)
      os.chmod(path_mafft, 0755)  # Assume it's a file
  #-------------------------------------------------------------------------------
  # Corregindo Mafft e removendo pipes
  #-------------------------------------------------------------------------------
  import makeRemovePipe_aa 
  corrected_file = makeRemovePipe_aa.paramModule(path_mafft)
  #-------------------------------------------------------------------------------
  # Executando Readseq
  #-------------------------------------------------------------------------------
  import makeReadseq_aa
  makeReadseq_aa.paramModuleReadseq(path_mafft)
  #-------------------------------------------------------------------------------
  # Executando Modelgenerator
  #-------------------------------------------------------------------------------
def modelgenerator_execute(dirin):
  import makeModelgenerator_aa
  model_found = makeModelgenerator_aa.paramModuleModelgenerator(dirin)
  return model_found
#-------------------------------------------------------------------------------
#PARTE II: PARTE ELETIVA: POR ALGORITMO
#-------------------------------------------------------------------------------
  #   4.- Executando Phyml
  #-------------------------------------------------------------------------------
def program_execute(dirin, model, program, bootstrap, ngeneration, printfreq, samplefreq, nchains, burnin, nruns, rates_mrbayes, nb_categ, alpha, invar, rates_raxml_aa,freq_raxml_aa):
  if program == 'phyml':
    if bootstrap is None:
      bootstrap = '100'
    if nb_categ is None:
      nb_categ = '4'
    if alpha is None:
      alpha = '1.0'
    if invar is None:
      invar = '0.0'
    import makePhyml_aa_last 
    makePhyml_aa_last.ModulePhyml(dirin, model, bootstrap, nb_categ, alpha, invar)
  
  if program == 'paup_nj':
    if bootstrap is None:
      bootstrap = '10000'
    import makePaupNJParamModule_aa
    makePaupNJParamModule_aa.ModulePaupNJ(dirin, bootstrap)

  if program == 'paup_mp':
    if bootstrap is None:
      bootstrap = '500'
    import makePaupMPParamModule_aa
    makePaupMPParamModule_aa.ModulePaupMP(dirin, bootstrap)

  if program == 'weighbor':
    if bootstrap is None:
      bootstrap = '100'
    if nb_categ is None:
      nb_categ = '6'
    import makeWeighbor_aa
    makeWeighbor_aa.ModuleWeighbor(dirin, model, bootstrap, nb_categ)

  if program == 'raxml': #na vivax segmentation fault
    if bootstrap is None:
      bootstrap = '100'
    if rates_raxml_aa is None:
      rates_raxml_aa = 'PROTGAMMA'
    if freq_raxml_aa is None:
      freq_raxml_aa = 'F'
    if nb_categ is None:
      nb_categ = '4'
    import makeRaxml_aa
    makeRaxml_aa.ModuleRaxml(dirin, model, bootstrap, nb_categ, rates_raxml_aa, freq_raxml_aa)
  
  if program == 'mrbayes':
    if ngeneration is None:
      ngeneration = '10000'
    if nb_categ is None:
      nb_categ = '4'
    if printfreq is None:
      printfreq = '100'
    if samplefreq is None:
      samplefreq = '100'
    if nchains is None:
      nchains = '4'
    if burnin is None:
      burnin = '10'
    if nruns is None:
      nruns = '2'
    if rates_mrbayes is None:
      rates_mrbayes = 'Equal'
    import makeMrBayes_aa
    makeMrBayes_aa.ModuleMrBayes(dirin, model, ngeneration, nb_categ, printfreq, samplefreq, nchains, burnin, nruns, rates_mrbayes)
    
  if program == 'algorithms_aa_1':
    bootstrap = '100'
    nb_categ = '4'
    alpha = '1.0'
    invar = '0.0'
    import makePhyml_aa_last 
    makePhyml_aa_last.ModulePhyml(dirin, model, bootstrap, nb_categ, alpha, invar)
    bootstrap = '10000'
    import makePaupNJParamModule_aa
    makePaupNJParamModule_aa.ModulePaupNJ(dirin, bootstrap)
    bootstrap = '500'
    import makePaupMPParamModule_aa
    makePaupMPParamModule_aa.ModulePaupMP(dirin, bootstrap)

  if program == 'algorithms_aa_2':
    bootstrap = '100'
    nb_categ = '6'
    import makeWeighbor_aa
    bootstrap = '10000'
    import makePaupNJParamModule_aa
    makePaupNJParamModule_aa.ModulePaupNJ(dirin, bootstrap)
    makeWeighbor_aa.ModuleWeighbor(dirin, model, bootstrap, nb_categ)
    bootstrap = '100'
    rates_raxml_aa = 'PROTGAMMA'
    freq_raxml_aa = 'F'
    nb_categ = '4'
    import makeRaxml_aa
    makeRaxml_aa.ModuleRaxml(dirin, model, bootstrap, nb_categ, rates_raxml_aa, freq_raxml_aa)

  if program == 'algorithms_aa_3':
    bootstrap = '100'
    nb_categ = '4'
    alpha = '1.0'
    invar = '0.0'
    import makePhyml_aa_last 
    makePhyml_aa_last.ModulePhyml(dirin, model, bootstrap, nb_categ, alpha, invar)
    bootstrap = '10000'
    import makePaupNJParamModule_aa
    makePaupNJParamModule_aa.ModulePaupNJ(dirin, bootstrap)
    bootstrap = '500'
    import makePaupMPParamModule_aa
    makePaupMPParamModule_aa.ModulePaupMP(dirin, bootstrap)
    bootstrap = '100'
    nb_categ = '6'
    import makeWeighbor_aa
    makeWeighbor_aa.ModuleWeighbor(dirin, model, bootstrap, nb_categ)
    bootstrap = '100'
    rates_raxml_aa = 'PROTGAMMA'
    freq_raxml_aa = 'F'
    nb_categ = '4'
    import makeRaxml_aa
    makeRaxml_aa.ModuleRaxml(dirin, model, bootstrap, nb_categ, rates_raxml_aa, freq_raxml_aa)
    ngeneration = '10000'
    nb_categ = '4'
    printfreq = '100'
    samplefreq = '100'
    nchains = '4'
    burnin = '10'
    nruns = '2'
    rates_mrbayes = 'Equal'
    import makeMrBayes_aa
    makeMrBayes_aa.ModuleMrBayes(dirin, model, ngeneration, nb_categ, printfreq, samplefreq, nchains, burnin, nruns, rates_mrbayes)
    
if __name__ == "__main__":
  main()

