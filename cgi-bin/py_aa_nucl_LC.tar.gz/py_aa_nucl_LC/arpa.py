#! /usr/bin/env python

# TITULO            : ARPA pipeline
# AUTOR             : Kary Ocana
# DATA              : 01/07/2009
# DIFICULDADE       : 1
# ==============================================================================
# Objetivo do script: Rodado como o programa principal. Executar Mafft, Readseq,
#                     remove_pipe, Modelgenerator, modulos/script e algoritmos de filogenia 
# Usar o argumento  : Ver usage
# ==============================================================================
# Data da ultima alteracao do script: 01/07/2009
# ==============================================================================
#-------------------------------------------------------------------------------
# declarando os modulos a usar 
#-------------------------------------------------------------------------------
import os, sys, commands, re, shutil as sh, optparse
import sys
import getopt
from optparse import OptionParser

def validate_parameters(program):
  programAllDefault = ['phyml', 'paup_nj', 'paup_mp', 'paup_ml','weighbor', 'raxml', 'garli', 'mrbayes', 'algorithms_aa_1', 'algorithms_aa_2', 'algorithms_aa_3']  
  if (esta_em_programAllDefault(program, programAllDefault)):
    return 1
  else:
    print "The program is unrecognizable"
    sys.exit(2)

def esta_em_programAllDefault(program, programAllDefault):
  for p in programAllDefault:
    if program.lower() == p.lower():
      print 'Program found: ' + p
      return 1
  return 0

def alphabet_nucl(filename):
  file = open(filename)
  achou = 1
  cont = 0
  lista = []
  for line in file.readlines():
    if line[0] != '>':
      cont = cont + 1
      tam = len (line)
      for i in range(tam):
        if line [i] != 'A' and line [i] != 'T' and line [i] != 'C' and line [i] != 'G':
          if line [i] == '\n': break
          print "It is not nucleotide. Erro in line %d - position %d" % (cont, i+1)
          return 0
        else:
          print "Data_type found: nucl (nucleotide)"
          return 1
  file.close()

def alphabet_aa (filename):
  if ('A' <= filename <= 'Z' or 'a' <= filename <= 'z'):# and filename not in 'jou JOU':
    print "Data_type found: aa (amino acid)"
    return 1
  else:
    print "It is not amino acid"
    #sys.exit(2)
    return 0

def modelgenerator_nucl(model): #mudar para nucl
  modelAllDefault = ['JC','F81','HKY','K80','SYM','GTR','TrN','TrNef','TVM','TIM','K81uf','K81'] #suported for phyml, weighbor, raxml and mrbayes 
  if (esta_em_programAllDefault(model, modelAllDefault)):
    return 1
  else:
    print "The model is unrecognizable"
    sys.exit(2)
    
def modelgenerator_aa(model):
  modelAllDefault = ['BLOSUM62','CPREV','Dayhoff','JTT','MTREV24','VT','WAG','DCMut','RtREV','MtMam','MtArt','MtREV','poisson','jones','BLOSUM','equalin','GTR'] #suported for phyml, weighbor, raxml and mrbayes 
  if (esta_em_modelAllDefault(model, modelAllDefault)):
    return 1
  else:
    print "The model is unrecognizable"
    sys.exit(2)

def esta_em_modelAllDefault(model, modelAllDefault):
  for m in modelAllDefault:
    if model.lower() == m.lower():
      print m
      return 1
  return 0    
  
def make_dir(dirin, filename): 
  try:
    os.mkdir(dirin)
    print 'Directory', dirin,'created sucessfully'
  except OSError:
    print "Directory exists"
    sys.exit(2)
  sh.copy(filename, dirin)

def lset_rates_mrbayes(rates_mrbayes):
  ratesAllDefault = ['Equal','Gamma','Propinv','Invgamma','Adgamma'] #suported for mrbayes
  if (esta_em_modelAllDefault(rates_mrbayes, ratesAllDefault)):
    return 1
  else:
    print "The rates for mrbayes is unrecognizable"
    sys.exit(2)

def rrates_raxml_aa(rates_raxml_aa):
  ratesAllDefault = ['PROTCAT','PROTCATI','PROTGAMMA','PROTGAMMAI'] #suported for raxml
  if (esta_em_modelAllDefault(rates_raxml_aa, ratesAllDefault)):
    return 1
  else:
    print "The rates for raxml is unrecognizable"
    sys.exit(2)
    
def ffreq_raxml_aa(freq_raxml_aa):
  freqAllDefault = ['F'] #suported for raxml
  if (esta_em_modelAllDefault(freq_raxml_aa, freqAllDefault)):
    return 1
  else:
    print "The frequency for raxml is unrecognizable"
    sys.exit(2)

def rrates_raxml_nucl(rates_raxml_nucl):
  ratesAllDefault = ['CAT','CATI','GAMMA','GAMMAI'] #suported for raxml
  if (esta_em_modelAllDefault(rates_raxml_nucl, ratesAllDefault)):
    return 1
  else:
    print "The rates for raxml is unrecognizable"
    sys.exit(2)

def rrates_paup_ml_nucl(rates_paup_ml_nucl):
  ratesAllDefault = ['Equal','Gamma','SiteSpec'] #suported for paup ML nucl
  if (esta_em_modelAllDefault(rates_paup_ml_nucl, ratesAllDefault)):
    return 1
  else:
    print "The rates for raxml is unrecognizable"
    sys.exit(2)
   
def main():
  #usage = "python %prog [-h] [-t] data_type [-i] file [-o] dirin [-p] phyml [--mg] model [--bp] bootstrap [--nb] nb_categ [--a] alpha [--in] invar"
  usage = "%prog [-t] data_type [-o] dirin [-p] program [options] <multifasta.fasta>"
  parser = OptionParser(usage)
  parser.add_option("-t", dest="data_type", help="amino acid or nucluotide: aa/nucl")
  #parser.add_option("-i", dest="filename", help="a fasta file to process", metavar="FILE")
  parser.add_option("-o", dest="directory", help="directory for store the results", )
  parser.add_option("-p", dest="program", help="phylogenetic program: phyml/paup_nj/paup_mp/paup_ml/weighbor/raxml/garli/mrbayes/algorithms_(aa/nucl)_1(phyml,paup_nj,paup_mp)/algorithms_(aa/nucl)_2(paup_nj,weighbor,raxMl)/algorithms_(aa/nucl)_3(all)",)
  parser.add_option("--mg", dest="model", help="evolutionary model name")
  parser.add_option("--bp", dest="bootstrap", type="int", help="bootstrap values")
  parser.add_option("--ngen", dest="ngeneration", type="int", help="generation number (mrbayes)")
  parser.add_option("--printfreq", dest="printfreq", type="int", help="how often information about the chain is printed to the screen (mrbayes)")
  parser.add_option("--samplefreq", dest="samplefreq", type="int", help="how often the Markov chain is sampled (mrbayes)")
  parser.add_option("--nchains", dest="nchains", type="int", help="how many chains are run for each analysis for the MCMCMC variant (mrbayes)")                                        
  parser.add_option("--burnin", dest="burnin", type="int", help="the number of samples that will be discarded when convergence diagnostics are calculated (mrbayes)")                                         
  parser.add_option("--nruns", dest="nruns", type="int", help="how many independent analyses are started simultaneously (mrbayes)")                                         
  parser.add_option("--rates_mrbayes", dest="rates_mrbayes", help="sets the model for among-site rate variation: Equal,Gamma,Propinv,Invgamma,Adgamma (mrbayes)")
  parser.add_option("--nb", dest="nb_categ", type="int", help="number of substitution rate categories (phyml)")
  parser.add_option("--a", dest="alpha", type="float", help="gamma distribution values (phyml, paup_ml)")
  parser.add_option("--in", dest="invar", type="float", help="proportion of invariable sites (phyml)")
  parser.add_option("--rates_raxml_aa", dest="rates_raxml_aa", help="substitution rates: PROTCAT,PROTCATI,PROTGAMMA,PROTGAMMAI (raxml)")
  parser.add_option("--rates_raxml_nucl", dest="rates_raxml_nucl", help="substitution rates: CAT,CATI,GAMMA,GAMMAI (raxml)")
  parser.add_option("--freq_aa", dest="freq_raxml_aa", help="use empirical base frequencies: F (raxml)")
  parser.add_option("--kappa", dest="kappa", type="int", help="transition/transversion ratio, only for DNA sequences (phyml)")
  parser.add_option("--rates_paup_ml_nucl", dest="rates_paup_ml_nucl", help="sets the model for among-site rate variation: Equal,Gamma,SiteSpec (paup_ml)")
  parser.add_option("-v", action="store_true", dest="verbose")
  parser.add_option("-q", action="store_false", dest="verbose")
  (options, args) = parser.parse_args()
  if len(args) != 1: 
      parser.error("Incorrect number of arguments")
      sys.exit(2)

  #4 parametros obrigatorios
  data_type = options.data_type
  dirin = options.directory
  filename = sys.argv[len(sys.argv)-1] #options.filename
  program = options.program
  model = options.model
  bootstrap = options.bootstrap
  ngeneration = options.ngeneration
  printfreq = options.printfreq
  samplefreq = options.samplefreq
  nchains = options.nchains
  burnin = options.burnin
  nruns = options.nruns
  rates_mrbayes = options.rates_mrbayes
  nb_categ = options.nb_categ
  alpha = options.alpha
  invar = options.invar
  rates_raxml_aa = options.rates_raxml_aa
  freq_raxml_aa = options.freq_raxml_aa
  kappa = options.kappa
  rates_raxml_nucl = options.rates_raxml_nucl
  rates_paup_ml_nucl = options.rates_paup_ml_nucl
  
  #Validando programa (filogenetico)
  validate_parameters(program)
  
  #Validando data_type (alphabeto) and model
  if data_type == 'nucl':
    if alphabet_nucl(filename) == True:
      if model is not None:
        modelgenerator_nucl(model)
        if rates_raxml_aa is not None:
          print "Pass rates_raxml_nucl"
          sys.exit(2)
        if rates_raxml_nucl is not None:
          rrates_raxml_nucl(rates_raxml_nucl)
        if rates_mrbayes is not None:    
          lset_rates_mrbayes(rates_mrbayes)
        if rates_paup_ml_nucl is not None:    
          rrates_paup_ml_nucl(rates_paup_ml_nucl)
        make_dir(dirin, filename)
        mafft_clean_readseq(dirin)
        program_execute_nucl(dirin, model, program, bootstrap, ngeneration, printfreq, samplefreq, nchains, burnin, nruns, rates_mrbayes, nb_categ, alpha, invar, kappa, rates_raxml_nucl, rates_paup_ml_nucl)
      if model is None:
        if rates_raxml_nucl is not None:
          rrates_raxml_nucl(rates_raxml_nucl)
        if rates_mrbayes is not None: 
          lset_rates_mrbayes(rates_mrbayes)
        if rates_paup_ml_nucl is not None:    
          rrates_paup_ml_nucl(rates_paup_ml_nucl)  
        make_dir(dirin, filename)
        mafft_clean_readseq(dirin)
        modelmg = modelgenerator_execute(dirin)
        program_execute_nucl(dirin, modelmg, program, bootstrap, ngeneration, printfreq, samplefreq, nchains, burnin, nruns, rates_mrbayes, nb_categ, alpha, invar, kappa, rates_raxml_nucl, rates_paup_ml_nucl)
  elif data_type == 'aa':
    if alphabet_nucl(filename) == False and alphabet_aa(filename) == True:
      if model is not None:
        modelgenerator_aa(model)
        if rates_raxml_nucl is not None:
          print "Pass rates_raxml_aa"
          sys.exit(2)
        if freq_raxml_aa is not None:
          ffreq_raxml_aa(freq_raxml_aa)
        if rates_raxml_aa is not None:
          rrates_raxml_aa(rates_raxml_aa)
        if rates_mrbayes is not None:
          lset_rates_mrbayes(rates_mrbayes)
        make_dir(dirin, filename)
        mafft_clean_readseq(dirin)
        program_execute_aa(dirin, model, program, bootstrap, ngeneration, printfreq, samplefreq, nchains, burnin, nruns, rates_mrbayes, nb_categ, alpha, invar, rates_raxml_aa, freq_raxml_aa)
      if model is None:
        if freq_raxml_aa is not None:
          ffreq_raxml_aa(freq_raxml_aa)
        if rates_raxml_aa is not None:
          rrates_raxml_aa(rates_raxml_aa)
        if rates_mrbayes is not None:
          lset_rates_mrbayes(rates_mrbayes)
        make_dir(dirin, filename)
        mafft_clean_readseq(dirin)
        modelmg = modelgenerator_execute(dirin)
        program_execute_aa(dirin, modelmg, program, bootstrap, ngeneration, printfreq, samplefreq, nchains, burnin, nruns, rates_mrbayes, nb_categ, alpha, invar, rates_raxml_aa,freq_raxml_aa)
  else:
    print "Pass 'aa' or 'nucl' as data_type"
    sys.exit(2)
  #-------------------------------------------------------------------------------
  #PARTE I: OBRIGATORIO
def mafft_clean_readseq(dirin):
  #-------------------------------------------------------------------------------
  # Executando Mafft
  #-------------------------------------------------------------------------------
  import makeMafft_aa 
  makeMafft_aa.paramModuleExecution(dirin)
  #-------------------------------------------------------------------------------
  # Trabalhando com o arquivo mafft
  #-------------------------------------------------------------------------------
  for m in os.listdir(dirin):
    if m.endswith('.mafft'):                                                    
      path_mafft = os.path.join(dirin, m)
      os.chmod(path_mafft, 0755)  # Assume it's a file
  #-------------------------------------------------------------------------------
  # Corregindo Mafft e removendo pipes
  #-------------------------------------------------------------------------------
  import makeRemovePipe_aa 
  corrected_file = makeRemovePipe_aa.paramModule(path_mafft)
  #-------------------------------------------------------------------------------
  # Executando Readseq
  #-------------------------------------------------------------------------------
  import makeReadseq_aa
  makeReadseq_aa.paramModuleReadseq(path_mafft)
  #-------------------------------------------------------------------------------
  # Executando Modelgenerator
  #-------------------------------------------------------------------------------
def modelgenerator_execute(dirin):
  import makeModelgenerator_aa
  model_found = makeModelgenerator_aa.paramModuleModelgenerator(dirin)
  return model_found
#-------------------------------------------------------------------------------
#PARTE II: PARTE ELETIVA: POR ALGORITMO
#-------------------------------------------------------------------------------
  #   4.- Executando Phyml
  #-------------------------------------------------------------------------------
def program_execute_aa(dirin, model, program, bootstrap, ngeneration, printfreq, samplefreq, nchains, burnin, nruns, rates_mrbayes, nb_categ, alpha, invar, rates_raxml_aa, freq_raxml_aa):
  if program == 'phyml':
    if bootstrap is None:
      bootstrap = '100'
    if nb_categ is None:
      nb_categ = '4'
    if alpha is None:
      alpha = '1.0'
    if invar is None:
      invar = '0.0'
    import makePhyml_aa_last 
    makePhyml_aa_last.ModulePhyml(dirin, model, bootstrap, nb_categ, alpha, invar)
  
  if program == 'paup_nj':
    if bootstrap is None:
      bootstrap = '10000'
    import makePaupNJParamModule_aa
    makePaupNJParamModule_aa.ModulePaupNJ(dirin, bootstrap)

  if program == 'paup_mp':
    if bootstrap is None:
      bootstrap = '500'
    import makePaupMPParamModule_aa
    makePaupMPParamModule_aa.ModulePaupMP(dirin, bootstrap)

  if program == 'weighbor':
    if bootstrap is None:
      bootstrap = '100'
    if nb_categ is None:
      nb_categ = '6'
    import makeWeighbor_aa
    makeWeighbor_aa.ModuleWeighbor(dirin, model, bootstrap, nb_categ)

  if program == 'raxml':
    if bootstrap is None:
      bootstrap = '100'
    if rates_raxml_aa is None:
      rates_raxml_aa = 'PROTGAMMA'
      nb_categ = '4'
    if rates_raxml_aa is 'PROTGAMMA' or 'PROTGAMMAI':
      nb_categ = '4'
    if freq_raxml_aa is None or 'f':
      freq_raxml_aa = 'F'
    if nb_categ is None:
      nb_categ = '4'
    import makeRaxml_aa
    makeRaxml_aa.ModuleRaxml(dirin, model, bootstrap, nb_categ, rates_raxml_aa, freq_raxml_aa)
    
  if program == 'garli':
    if bootstrap is None:
      bootstrap = '100'
    if nb_categ is None:
      nb_categ = '4'
    import makeGarli_aa
    makeGarli_aa.ModuleGarli(dirin, model, bootstrap, nb_categ)
    
  if program == 'mrbayes':
    if ngeneration is None:
      ngeneration = '10000'
    if nb_categ is None:
      nb_categ = '4'
    if printfreq is None:
      printfreq = '100'
    if samplefreq is None:
      samplefreq = '100'
    if nchains is None:
      nchains = '4'
    if burnin is None:
      burnin = '10'
    if nruns is None:
      nruns = '2'
    if rates_mrbayes is None:
      rates_mrbayes = 'Equal'
    import makeMrBayes_aa
    makeMrBayes_aa.ModuleMrBayes(dirin, model, ngeneration, nb_categ, printfreq, samplefreq, nchains, burnin, nruns, rates_mrbayes)
    
  if program == 'algorithms_aa_1':
    bootstrap = '100'
    nb_categ = '4'
    alpha = '1.0'
    invar = '0.0'
    import makePhyml_aa_last 
    makePhyml_aa_last.ModulePhyml(dirin, model, bootstrap, nb_categ, alpha, invar)
    bootstrap = '10000'
    import makePaupNJParamModule_aa
    makePaupNJParamModule_aa.ModulePaupNJ(dirin, bootstrap)
    bootstrap = '500'
    import makePaupMPParamModule_aa
    makePaupMPParamModule_aa.ModulePaupMP(dirin, bootstrap)

  if program == 'algorithms_aa_2':
    bootstrap = '100'
    nb_categ = '6'
    import makeWeighbor_aa
    bootstrap = '10000'
    import makePaupNJParamModule_aa
    makePaupNJParamModule_aa.ModulePaupNJ(dirin, bootstrap)
    makeWeighbor_aa.ModuleWeighbor(dirin, model, bootstrap, nb_categ)
    bootstrap = '100'
    rates_raxml_aa = 'PROTGAMMA'
    freq_raxml_aa = 'F'
    nb_categ = '4'
    import makeRaxml_aa
    makeRaxml_aa.ModuleRaxml(dirin, model, bootstrap, nb_categ, rates_raxml_aa, freq_raxml_aa)

  if program == 'algorithms_aa_3':
    bootstrap = '100'
    nb_categ = '4'
    alpha = '1.0'
    invar = '0.0'
    import makePhyml_aa_last 
    makePhyml_aa_last.ModulePhyml(dirin, model, bootstrap, nb_categ, alpha, invar)
    bootstrap = '10000'
    import makePaupNJParamModule_aa
    makePaupNJParamModule_aa.ModulePaupNJ(dirin, bootstrap)
    bootstrap = '500'
    import makePaupMPParamModule_aa
    makePaupMPParamModule_aa.ModulePaupMP(dirin, bootstrap)
    bootstrap = '100'
    nb_categ = '6'
    import makeWeighbor_aa
    makeWeighbor_aa.ModuleWeighbor(dirin, model, bootstrap, nb_categ)
    bootstrap = '100'
    rates_raxml_aa = 'PROTGAMMA'
    freq_raxml_aa = 'F'
    nb_categ = '4'
    import makeRaxml_aa
    makeRaxml_aa.ModuleRaxml(dirin, model, bootstrap, nb_categ, rates_raxml_aa, freq_raxml_aa)
    ngeneration = '10000'
    nb_categ = '4'
    printfreq = '100'
    samplefreq = '100'
    nchains = '4'
    burnin = '10'
    nruns = '2'
    rates_mrbayes = 'Equal'
    import makeMrBayes_aa
    makeMrBayes_aa.ModuleMrBayes(dirin, model, ngeneration, nb_categ, printfreq, samplefreq, nchains, burnin, nruns, rates_mrbayes)

def program_execute_nucl(dirin, model, program, bootstrap, ngeneration, printfreq, samplefreq, nchains, burnin, nruns, rates_mrbayes, nb_categ, alpha, invar, kappa, rates_raxml_nucl, rates_paup_ml_nucl):
  if program == 'phyml':
    if bootstrap is None:
      bootstrap = '100'
    if nb_categ is None:
      nb_categ = '1'
    if alpha is None:
      alpha = '1.0'
    if kappa is None:
      kappa = '4.0'
    import makePhyml_nucl 
    makePhyml_nucl.ModulePhyml(dirin, model, bootstrap, nb_categ, alpha, kappa)
  
  if program == 'paup_nj':
    if bootstrap is None:
      bootstrap = '10000'
    import makePaupNJParamModule_nucl
    makePaupNJParamModule_nucl.ModulePaupNJ(dirin, bootstrap)

  if program == 'paup_mp':
    if bootstrap is None:
      bootstrap = '500'
    import makePaupMPParamModule_nucl
    makePaupMPParamModule_nucl.ModulePaupMP(dirin, bootstrap)

  if program == 'paup_ml':
    if bootstrap is None:
      bootstrap = '100'
    if nb_categ is None:
      nb_categ = '4'
    if alpha is None:
      alpha = '0.5'
    if invar is None:
      invar = '0'
    if rates_paup_ml_nucl is None:
      rates_paup_ml_nucl = 'Equal'
    import makePaupML_nucl
    makePaupML_nucl.ModulePaupML(dirin, model, bootstrap, nb_categ, rates_paup_ml_nucl, alpha, invar)
    
  if program == 'garli':
    if bootstrap is None:
      bootstrap = '100'
    if nb_categ is None:
      nb_categ = '4'
    import makeGarli_nucl
    makeGarli_nucl.ModuleGarli(dirin, model, bootstrap, nb_categ)
    
  if program == 'weighbor':
    if bootstrap is None:
      bootstrap = '100'
    if nb_categ is None:
      nb_categ = '4'
    import makeWeighbor_nucl
    makeWeighbor_nucl.ModuleWeighbor(dirin, model, bootstrap, nb_categ)

  if program == 'raxml':
    if bootstrap is None:
      bootstrap = '100'
    if rates_raxml_nucl is None:
      rates_raxml_nucl = 'GAMMA'
      nb_categ = '4'
    if rates_raxml_nucl is 'GAMMA' or 'GAMMAI':
      nb_categ = '4'
    if nb_categ is None:
      nb_categ = '4'
    import makeRaxml_nucl
    makeRaxml_nucl.ModuleRaxml(dirin, model, bootstrap, nb_categ, rates_raxml_nucl)
  
  if program == 'mrbayes':
    if ngeneration is None:
      ngeneration = '10000'
    if nb_categ is None:
      nb_categ = '4'
    if printfreq is None:
      printfreq = '100'
    if samplefreq is None:
      samplefreq = '100'
    if nchains is None:
      nchains = '4'
    if burnin is None:
      burnin = '10'
    if nruns is None:
      nruns = '2'
    if rates_mrbayes is None:
      rates_mrbayes = 'Equal'
    import makeMrBayes_nucl
    makeMrBayes_nucl.ModuleMrBayes(dirin, model, ngeneration, nb_categ, printfreq, samplefreq, nchains, burnin, nruns, rates_mrbayes)
    
  if program == 'algorithms_nucl_1':
    bootstrap = '100'
    nb_categ = '1'
    alpha = '1.0'
    kappa = '4.0'
    import makePhyml_nucl 
    makePhyml_nucl.ModulePhyml(dirin, model, bootstrap, nb_categ, alpha, kappa)
    bootstrap = '10000'
    import makePaupNJParamModule_nucl
    makePaupNJParamModule_nucl.ModulePaupNJ(dirin, bootstrap)
    bootstrap = '500'
    import makePaupMPParamModule_nucl
    makePaupMPParamModule_nucl.ModulePaupMP(dirin, bootstrap)

  if program == 'algorithms_nucl_2':
    bootstrap = '100'
    nb_categ = '4'
    import makeWeighbor_nucl
    makeWeighbor_nucl.ModuleWeighbor(dirin, model, bootstrap, nb_categ)
    bootstrap = '10000'
    import makePaupNJParamModule_aa
    bootstrap = '100'
    rates_raxml_nucl = 'GAMMA'
    nb_categ = '4'
    import makeRaxml_nucl
    makeRaxml_nucl.ModuleRaxml(dirin, model, bootstrap, nb_categ, rates_raxml_nucl)

  if program == 'algorithms_nucl_3':
    bootstrap = '100'
    nb_categ = '1'
    alpha = '1.0'
    kappa = '4.0'
    import makePhyml_nucl 
    makePhyml_nucl.ModulePhyml(dirin, model, bootstrap, nb_categ, alpha, kappa)
    bootstrap = '10000'
    import makePaupNJParamModule_nucl
    makePaupNJParamModule_nucl.ModulePaupNJ(dirin, bootstrap)
    bootstrap = '500'
    import makePaupMPParamModule_nucl
    makePaupMPParamModule_nucl.ModulePaupMP(dirin, bootstrap)
    bootstrap = '100'
    nb_categ = '4'
    alpha = '0.5'
    invar = '0'
    rates_paup_ml_nucl = 'Equal'
    import makePaupML_nucl
    makePaupML_nucl.ModulePaupML(dirin, model, bootstrap, nb_categ, rates_paup_ml_nucl, alpha, invar)
    bootstrap = '100'
    nb_categ = '4'
    import makeGarli_nucl
    makeGarli_nucl.ModuleGarli(dirin, model, bootstrap, nb_categ)
    bootstrap = '100'
    nb_categ = '4'
    import makeWeighbor_nucl
    makeWeighbor_nucl.ModuleWeighbor(dirin, model, bootstrap, nb_categ)
    bootstrap = '100'
    rates_raxml_nucl = 'GAMMA'
    nb_categ = '4'
    import makeRaxml_nucl
    makeRaxml_nucl.ModuleRaxml(dirin, model, bootstrap, nb_categ, rates_raxml_nucl)
  if program == 'mrbayes':
    ngeneration = '10000'
    nb_categ = '4'
    printfreq = '100'
    samplefreq = '100'
    nchains = '4'
    burnin = '10'
    nruns = '2'
    rates_mrbayes = 'Equal'
    import makeMrBayes_nucl
    makeMrBayes_nucl.ModuleMrBayes(dirin, model, ngeneration, nb_categ, printfreq, samplefreq, nchains, burnin, nruns, rates_mrbayes)
    
if __name__ == "__main__":
  main()

